package com.example.listlab;
import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends Activity {

    private ListView listview1;
    private ArrayList<String> mylist = new ArrayList<>();
    private int[] images = {
            R.drawable.ic_info_white_24dp, R.drawable.ic_lock_white_24dp,
            R.drawable.ic_security_white, R.drawable.ic_volume_up_white,
            R.drawable.home};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listview1 = findViewById(R.id.mainListview1);

        listview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View child, int pos, long _pos) {
                Toast.makeText(getApplicationContext(), mylist.get(pos), Toast.LENGTH_LONG).show();
            }
        });

        mylist.add("phone repair");
        mylist.add("icloud storage");
        mylist.add("internet");
        mylist.add("Recharge balance");

        MyAdapter adapter = new MyAdapter(this, mylist);
        listview1.setAdapter(adapter);
    }

    public class MyAdapter extends ArrayAdapter<String> {
        public MyAdapter(Context context, ArrayList<String> string_list) {
            super(context, 0, string_list);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_item, parent, false);
            }
            parent.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            TextView txtview = (TextView) convertView.findViewById(R.id.listitemTextView1);
            ImageView imgview = (ImageView) convertView.findViewById(R.id.listitemImageView1);

            txtview.setText(mylist.get(position));
            imgview.setImageResource(images[position]);

            return convertView;
        }
    }
}

