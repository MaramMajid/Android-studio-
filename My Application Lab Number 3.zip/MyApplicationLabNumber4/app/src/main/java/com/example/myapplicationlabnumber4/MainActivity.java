package com.example.myapplicationlabnumber4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class MainActivity extends AppCompatActivity {
    ImageView AmChar;
    Spinner AmoungInfo;
    int currentItem=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        AmChar = findViewById(R.id.simpleImageView);
        AmoungInfo= (Spinner) findViewById(R.id.spinner);
        AmoungInfo.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if(i==currentItem){
                    return;
                }else if (i==1) {
               Intent intent = new Intent(MainActivity.this,MainActivity2.class);
                    startActivity(intent);
                }
                else if (i==2) {
                    Intent intent = new Intent(MainActivity.this,MainActivity3.class);
                    startActivity(intent);
                }else{
                    Intent intent = new Intent(MainActivity.this,MainActivity4.class);
                    startActivity(intent);

                }


            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

    }

    public void onRadioButtonClicked(View view) {
        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();
        // Check which radio button was clicked
        switch(view.getId()) {
            case R.id.red:
                if (checked)
                    AmChar.setImageResource(R.drawable.d2);
                // Pirates are the best
                    break;
            case R.id.green:
                if (checked)
                    AmChar.setImageResource(R.drawable.d3);
                    // Ninjas rule
                    break;

            case R.id.white:
                if (checked)
                    AmChar.setImageResource(R.drawable.d4);
                    // Ninjas rule
                    break;
        }
    }



    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);

        // Checks the orientation of the screen
        if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            Toast.makeText(this, "landscape", Toast.LENGTH_SHORT).show();
        } else if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT){
            Toast.makeText(this, "portrait", Toast.LENGTH_SHORT).show();
        }
    }

}
