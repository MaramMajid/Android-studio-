package com.example.mylabnumber2;

import androidx.appcompat.app.AppCompatActivity;
import android.widget.Button;
import android.view.*;


import android.os.Bundle;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
private int r1,r2;
private int count=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        GiveMerandomNumber();

        }
    private void GiveMerandomNumber(){

        Random rand= new Random();
         r1= rand.nextInt(10);
        while (true) {
            r2= rand.nextInt(10);
        if(r1!=r2)break;
        }
        Button LeftButton = (Button) findViewById(R.id.button1);
        LeftButton.setText(Integer.toString(r1));
        Button RightButton = (Button) findViewById(R.id.button2);
        RightButton.setText(Integer.toString(r2));

    }
    public void onClickLeft(View view) {

        if(r1>r2){
            count++;
        }
        else {count--;
            TextView texts=(TextView)findViewById(R.id.textView3);
            texts.setText("point:"+count);
            GiveMerandomNumber();
        }
    }
    public void onClickRight(View view) {
        if(r1<r2){
            count--;
        }
        else {count++;
            TextView texts=(TextView)findViewById(R.id.textView3);
            texts.setText("point:"+count);
            GiveMerandomNumber();
        }
    }
}
